## Goal

Move live crypto market data off the browser and behind a real backend. The frontend currently calls CoinGecko directly from `src/lib/use-markets.ts`, which leaks the request from every visitor's browser and gets rate-limited fast. We'll route it through a TanStack server function with in-memory caching.

## Changes

### 1. New server function — `src/lib/markets.functions.ts`
- `getMarkets` via `createServerFn({ method: "GET" })`.
- Calls `https://api.coingecko.com/api/v3/coins/markets` (15 coins, sparkline, 24h change).
- In-memory cache keyed by query, TTL 60s, to absorb concurrent requests and stay under CoinGecko's free-tier limits.
- Optional CoinGecko Pro key via `COINGECKO_API_KEY` env (Pro endpoint + `x-cg-pro-api-key` header). Free tier works without it; we won't prompt the user unless they ask.
- Maps response to the existing `Asset` shape (id, symbol, name, price, change24h, marketCap, volume, sparkline, about) so the UI doesn't change.
- On upstream failure, throws — the client falls back to bundled sample data.

### 2. Update `src/lib/use-markets.ts`
- Replace the direct `fetch` with `useServerFn(getMarkets)` wired into the existing `marketsQueryOptions` / `useQuery`.
- Keep `staleTime: 60_000`, `refetchInterval: 60_000`, and the sample-data fallback.

### 3. Leave everything else alone
- `Asset` type, `WatchlistSidebar`, `AssetWorkspace`, `StateEngine`, etc. all keep working unchanged.
- No DB tables, no auth, no edge functions — this is read-only public market data.

## Notes

- This is an internal app read, so a server function (not a public `/api/*` route) is the right boundary.
- No secret required for the free tier. If the user later wants higher limits, we can add `COINGECKO_API_KEY` via the secret flow.
