
-- Restrictive: nothing through anon/authenticated; only service_role (which bypasses RLS) can touch these.
CREATE POLICY "No client access" ON public.briefing_sends AS RESTRICTIVE FOR ALL TO anon, authenticated USING (false) WITH CHECK (false);
CREATE POLICY "No client access" ON public.briefing_snapshots AS RESTRICTIVE FOR ALL TO anon, authenticated USING (false) WITH CHECK (false);
CREATE POLICY "No client access" ON public.subscriber_watchlist AS RESTRICTIVE FOR ALL TO anon, authenticated USING (false) WITH CHECK (false);

-- Tighten the public signup policy: validate email shape and length instead of WITH CHECK (true).
DROP POLICY IF EXISTS "anon can sign up" ON public.briefing_subscribers;
CREATE POLICY "anon can sign up"
  ON public.briefing_subscribers
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    char_length(email) BETWEEN 3 AND 254
    AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
    AND status = 'active'
  );
