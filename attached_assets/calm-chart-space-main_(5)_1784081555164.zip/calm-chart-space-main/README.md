# Calm Terminal

**Understand crypto markets in 30 seconds.**

Calm Terminal is a market interpretation layer for crypto. It transforms raw price data into clear, readable market intelligence so you don't have to manually analyse charts, indicators, and noise.

Instead of showing you more data, it tells you **what changed, what matters, and what it means**.

## 🌿 Core Idea

Crypto tools today overload users with indicators: RSI, MACD, Volume, Price action, News, Sentiment.

Calm Terminal does the opposite. It answers a single question:

> What is actually happening right now, and did anything meaningful change?

## 🧠 The Truth Engine

At the core of Calm Terminal is the **Truth Engine**, which converts market signals into human-readable insights. It evaluates:

- **Trend** — Direction of the market
- **Momentum** — Strength and acceleration of movement
- **Volume** — Participation vs normal activity
- **Volatility** — Stability or expansion of price action
- **Position** — Where price sits within its recent range

### Example Output

Instead of raw indicators:

```
BTC: +2.1%
RSI: 63
Volume: +18%
```

You get:

> Bitcoin remains in an established uptrend. Momentum is positive but has slowed over the past week. Volume is slightly above average, suggesting moderate participation. No significant change in market structure.

## 🔄 Change Detection

Calm Terminal highlights **what changed**, not just current state.

> Momentum has weakened for the third consecutive day, despite price holding steady.

> For the first time in 30 days, Bitcoin has moved below its short-term trend.

## ⚙️ Features

- Real-time crypto market data (CoinGecko API)
- Natural language market summaries
- Change detection between time periods
- Minimal, distraction-free interface
- Portfolio-level interpretation _(coming soon)_
- Watchlist insights _(coming soon)_

## 🛠 Tech Stack

- **Framework:** TanStack Start (React + SSR)
- **Routing:** TanStack Router
- **Data:** TanStack Query
- **Styling:** Tailwind CSS + shadcn/ui
- **Charts:** Recharts
- **Language:** TypeScript
- **Data Source:** CoinGecko API

## 🚀 Getting Started

### Requirements

- Node.js 22+
- npm or bun

### Install

```bash
npm install
```

### Run Dev Server

```bash
npm run dev
```

Open: http://localhost:3000

## 📊 Philosophy

Calm Terminal is built on a simple principle:

> Most traders don't need more data. They need better interpretation.

We reduce cognitive load so users can make decisions faster, with less emotional interference.

## 🧭 Roadmap

- Portfolio intelligence layer
- Daily market summaries
- Historical change tracking
- Smart alerts ("something changed")
- Multi-asset comparison view
- Mobile app

## 💡 Positioning

- Not a trading platform.
- Not a charting tool.
- **A market interpretation layer.**

## 📄 License

MIT
